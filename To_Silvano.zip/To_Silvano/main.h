//
// File: main.h
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 02-Jun-2020 13:21:13
//
#ifndef MAIN_H
#define MAIN_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "main_types.h"

// Function Declarations
extern void main();

#endif

//
// File trailer for main.h
//
// [EOF]
//

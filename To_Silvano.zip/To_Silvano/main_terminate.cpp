//
// File: main_terminate.cpp
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 02-Jun-2020 13:21:13
//

// Include Files
#include "main.h"
#include "main_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void main_terminate()
{
  // (no terminate code required)
}

//
// File trailer for main_terminate.cpp
//
// [EOF]
//

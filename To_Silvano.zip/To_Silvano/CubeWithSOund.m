%Play Song
filedirectory = 'D:\PhD in Oxford,Ethz,KI,others\OxfordPhD\digital sound music(C++,matlab)\Frequency_Modulation_for_Digital_Synthesis_in_MATLAB\HornsE04.wav'
%[y, sr] = audioread('HornsE04Mono.wav');
[y, sr] = audioread(fullfile(filedirectory));
sound(y, sr)

display('Trial Notes: Twinkle Twinkle Little Star.')
note = ['1','1','5','5','6','6','5','-';'4','4','3','3','2','2','1','-'];
startnoteoffset = 0;
isminor = 0;
sr = 44100;
speed = 60;
ns =4;
s = 8;
unit = sr/ns*speed/60*s/8;
%note = ['8', '7', '8', '6', '3', '7', '5', '3', '-'; '8', '8', '7', '6', '8', '5', '7', '5'];
%note =['6', '-', '7', '5', '4', '3', '2', '1', '7', '1', '7', '-', '6', '5', '-'];
PLOT = 1;
TTLS = MakeScale_1(startnoteoffset, isminor, PLOT, speed, sr, ns, s, note, unit)
%TTLS = MakeScale(0, 0, sr, 1, 8, ['1', '1', '5', '5', '6', '6', '5', '-'; '4','4','3','3','2','2','1','-'])
%
%Plot one cube(facelet)
X = [0 3 3 0;0 0 0 0;0 3 3 0;3 3 3 3; 0 3 3 0; 0 3 3 0];
Y = [0 0 3 3;0 3 3 0;0 0 3 3;0 3 3 0; 0 0 0 0; 3 3 3 3];
Z = [0 0 0 0;0 0 3 3;3 3 3 3;0 0 3 3; 0 0 3 3; 0 0 3 3];

%Color = [hsv(1:ceil((length(hsv))/6):ceil(length(hsv)/6)*1); hsv(1:ceil((length(hsv)/6):ceil(length(hsv)/6)*2); hsv(1:ceil((length(hsv))/6):ceil(length(hsv)/6)*3; hsv(1:ceil((length(hsv))/6):ceil(length(hsv)/6)*4); hsv(1:ceil((length(hsvn))/6):ceil(length(hsv)/6)*5); winter(1:ceil((length(hsv))/6):ceil(length(hsv)/6)*6)]
%Color =[[cool(1) 0.5];[hot(1) 0.5];[spring(1) 0.5];[summer(1) 0.5];[autumn(1) 0.5]; [winter(1) 0.5]]
Color = [[spring(1) spring(1)]; [summer(1) summer(1)]; [autumn(1) autumn(1)]; [winter(1) winter(1)]];
figure,
fill3(X,Y,Z,Color')

display('Repeat Notes: ')    
figure(),
for i = 1:size(note, 1)
    for j = 1:size(note, 2)
        display('origin:')
        soundsc(TTLS(i, (j-1)*unit+1:j*unit), unit, 8)
        check= input(['input ', num2str(j),'th note.'])
        subplot(3,3,j)
        PLOT = 0
        switch check
            case '1'
%                fill3([0 1 1 0],[0 0 1 1],[0 0 0 0],TTLS(4, 1))
                pcolor([1 2; 1 2], [1 1; 2 2], reshape(Color(:,2), [2, 2]))
                MakeScale_1(startnoteoffset, isminor, PLOT, speed, sr, ns, 1, '1', unit)
            case '2'
%                fill3([1 2 2 1],[0 0 1 1],[0 0 0 0],TTLS(4, 1)) 
                pcolor([1 2; 1 2], [1 1; 2 2], reshape(Color(:,2), [2, 2]))
                MakeScale_1(startnoteoffset, isminor, PLOT, speed, sr, ns, 1, '2', unit)            
            case '3'
                pcolor([1 2; 1 2], [1 1; 2 2], reshape(Color(:,2), [2, 2]))
                %fill3([2 3 3 2],[0 0 1 1],[0 0 0 0],TTLS(4, 1))        
                MakeScale_1(startnoteoffset, isminor, PLOT, speed, sr, ns, 1, '3', unit)
            case '4'
                pcolor([1 2; 1 2], [1 1; 2 2], reshape(Color(:,2), [2, 2]) )
                %fill3([0 1 1 0],[1 1 2 2],[1 1 1 1], TTLS(4, 1))          
                MakeScale_1(startnoteoffset, isminor, PLOT, speed, sr, ns, 1, '4', unit)
            case '5'
                pcolor([1 2; 1 2], [1 1; 2 2], reshape(Color(:,2), [2, 2]) )
                %fill3([1 2 2 1],[1 1 2 2],[1 1 1 1], TTLS(4, 1))
                MakeScale_1(startnoteoffset, isminor,PLOT, speed, sr, ns, 1, '5', unit)            
            case '6'
                pcolor([1 2; 1 2], [1 1; 2 2], reshape(Color(:,2), [2, 2]) )
                %fill3([2 3 3 2],[1 1 2 2],[1 1 1 1], TTLS(4, 1))
                MakeScale_1(startnoteoffset, isminor,PLOT, speed, sr, ns, 1, '6', unit)
            case '7'
                pcolor([1 2; 1 2], [1 1; 2 2], reshape(Color(:,2), [2, 2]) )
                %fill3([0 1 1 0],[2 2 3 3],[2 2 2 2], TTLS(4, 1))  
                MakeScale_1(startnoteoffset, isminor,PLOT, speed, sr, ns, 1, '7', unit)
            case '8'
                pcolor([1 2; 1 2], [1 1; 2 2], reshape(Color(:,2), [2, 2]) )
                %fill3([1 2 2 1],[2 2 3 3],[2 2 2 2], TTLS(4, 1)) 
                MakeScale_1(startnoteoffset, isminor,PLOT, speed, sr, ns, 1, '8', unit)
            case '*'
                pcolor([1 2; 1 2], [1 1; 2 2], reshape(Color(:,2), [2, 2]) )
                %fill3([1 2 2 1],[2 2 3 3],[2 2 2 2], [0 0 0 0]) 
                MakeScale_1(startnoteoffset, isminor,PLOT, speed, sr, ns, 1, '*', unit)
            case '-'
                pcolor([1 2; 1 2], [1 1; 2 2], reshape(Color(:,2), [2, 2]) )
                MakeScale_1(startnoteoffset, isminor,PLOT, speed, sr, ns, 1, note(i, j-1), unit)
        end
    end
end
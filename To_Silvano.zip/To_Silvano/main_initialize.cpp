//
// File: main_initialize.cpp
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 02-Jun-2020 13:21:13
//

// Include Files
#include "main.h"
#include "main_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void main_initialize()
{
}

//
// File trailer for main_initialize.cpp
//
// [EOF]
//

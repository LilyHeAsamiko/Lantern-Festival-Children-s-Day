//
// File: main.cpp
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 02-Jun-2020 13:21:13
//

// Include Files
#include "main.h"
#include <stdio.h>

// Function Definitions

//
// display('Trial Notes: Twinkle Twinkle Little Star.')
// Arguments    : void
// Return Type  : void
//
void main()
{
  printf("Trial Notes: Twinkle Twinkle Little Star.");
  fflush(stdout);

  // note = ['8', '7', '8', '6', '3', '7', '5', '3', '-'; '8', '8', '7', '6', '8', '5', '7', '5']; 
  // note =['6', '-', '7', '5', '4', '3', '2', '1', '7', '1', '7', '-', '6', '5', '-']; 
  // outarray is an array of sound samples on the scale of (-1,1)
  // outarray contains the 8 notes of a diatonic musical scale
  // pace is 60 BPM defaultedly
  // in 4/4 time, 60BPM , each quarter note: 1s
  // each note is played for one second defaultedly , can be scaled by ns (4 defautedly) 
  // the sampling rate is 44100 samples/s
  // startnoteoffset is the number of semitones up or down from middle C at
  // which the scale should start.
  // If isminor == 0, a major scale is played; otherwise a minor scale is played. 
  // default: s = 8; ns = 4 for 1 pace, 4 paces in one octave;
  // display(['Please input the parameters: \n','startnoteoffset(defaut = 0 stands for middle of the major C): \n', 'isminor(default = 0 as major): \n', 'speed(default = 60BPM): \n', 'sr(default = 44100 samples per s): \n', 'pace number(default = 4 as 4/4): \n', 's(defult = 8 as 8 notes for crotchets octave): \n', 'note: your song note(format: no limit for notes in each line, each note as the minimum unit)']); 
  // ns = 4;
  // startoffset+3 : middle major C
  // .^ is element-by-element exponentiation
  // the statement above is equivalent to
  // Yes, ^ is exponentiation in MATLAB, rather than bitwise XOR as in C++
  //         display('Initialte the cube now(3*3*3).')
  printf("Initialte the cube now(3*3*3).");
  fflush(stdout);

  //  R = rubgen(d,0);
  // R = RUBGEN_1(d,0);
  // rubplot(R);
  //         display('Facelet Value Default to be UP.')
  //     sound(Outarray(i,:),sr,8)
  // dsp.AudioPlayer(sr,OUTPUT)
}

//
// File trailer for main.cpp
//
// [EOF]
//

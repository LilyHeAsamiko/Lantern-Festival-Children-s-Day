function Outarray = MakeScale_1(startnoteoffset_1 , isminor_1, PLOT_1, speed_1 , sr_1 , ns_1 , s_1 , note_1, unit_1)%#codegen
%outarray is an array of sound samples on the scale of (-1,1)
%outarray contains the 8 notes of a diatonic musical scale
%pace is 60 BPM defaultedly
%in 4/4 time, 60BPM , each quarter note: 1s 
%each note is played for one second defaultedly , can be scaled by ns (4 defautedly)
%the sampling rate is 44100 samples/s 
%startnoteoffset is the number of semitones up or down from middle C at
%which the scale should start.
%If isminor == 0, a major scale is played; otherwise a minor scale is played.
%default: s = 8; ns = 4 for 1 pace, 4 paces in one octave; 
startnoteoffset =  0 ;
isminor = 0;
ns = 4;
speed = 60;
sr =  44100 ;
s = 8 ;
note = ['1','2','3','4','5','6','7','8'];
unit = 11025;  
PLOT = 1;

%display(['Please input the parameters: \n','startnoteoffset(defaut = 0 stands for middle of the major C): \n', 'isminor(default = 0 as major): \n', 'speed(default = 60BPM): \n', 'sr(default = 44100 samples per s): \n', 'pace number(default = 4 as 4/4): \n', 's(defult = 8 as 8 notes for crotchets octave): \n', 'note: your song note(format: no limit for notes in each line, each note as the minimum unit)']);
if nargin < 9 %~exist('startnoteoffset') || ~exist('isminor')|| ~exist('speed') || ~exist('sr') || ~exist('ns') || ~exist('s') || ~exist('note')
%    fprintf(['Please check parameters input: \n','startnoteoffset(defaut = 0 stands for middle of the major C): \n', 'isminor(default = 0 as major): \n', 'speed(default = 60BPM): \n', 'sr(default = 44100 samples per s): \n', 'pace number(default = 4 as 4/4): \n', 's(defult = 8 as 8 notes for crotchets octave): \n', 'note: your song note(format: no limit for notes in each line, each note as the minimum unit)']);    
    fprintf('Please input of the parameters: \n');
    if ~isnumeric('startnoteoffset_1')
        startnoteoffset_1 = input_codegen('startnoteoffset(defaut = 0 stands for middle of the major C): \n');
        startnoteoffset = startnoteoffset_1;
    elseif ~isnumeric('isminor_1')
        isminor_1  = input_codegen('isminor(default = 0 as major): \n');
        isminor = isminor_1;
    elseif ~isnumeric('PLOT_1')
        PLOT_1  = input_codegen('PLOT(default = 1 as show figure): \n');
        PLOT = PLOT_1;
    elseif ~isnumeric('ns_1')
        ns_1 = input_codegen('pace number(default = 4 as 4/4): \n');
        ns = ns_1;
    elseif ~isnumeric('speed_1')
        speed_1 = input_codegen('speed(default = 60BPM): \n');
        speed = speed_1;
    elseif ~isnumeric('sr_1')
        sr_1 = input_codegen('sr(default = 44100 samples per s): \n');
        sr = sr_1;
    elseif ~isnumeric('s_1')
        s = input_codegen('s(defult = 8 as 8 notes for crotchets octave): \n');
    elseif ~isnumeric('note_1')
        note_1 = input_codegen('note: your song note(format: no limit for notes in each line, each note as the minimum unit)');
        note = note_1;
    elseif ~isnumeric('unit_1')
        unit_1 = input_codegen('unit(default = 11025)');    
        unit = unit_1;
    end
end  
np =speed/60;
%ns = 4;
majors=[0 2 4 5 7 9 11 12];%startoffset+3 : middle major C
minors=[0 2 3 5 7 8 10 12];
if(isminor == 0)
    scale = majors;
else
    scale = minors;
end
scale = scale/12;
scale = 2.^scale;
%.^ is element-by-element exponentiation
sr = round(np*sr/ns);
t = 1:sr;
t = t/sr;
%the statement above is equivalent to 
startnote = 220*(2^((startnoteoffset+3)/12));
scale = startnote * scale;
%Yes, ^ is exponentiation in MATLAB, rather than bitwise XOR as in C++

outarray = zeros(1,sr*s);
for i = 1:s
    outarray(1+(i-1)*sr:sr*i) = sin((2*pi*scale(i))*t);
end 
if PLOT == 1
    figure(),
    plot(outarray(1:100:ceil(length(outarray)/100)),'-o')
    title('Octave in major C')
end

assert(unit == sr)
if sr*ns==44100

    Outarray = zeros(size(note,1),unit*size(note,2));
    if PLOT == 1
        figure(),
        display('Initialte the cube now(3*3*3).')
%        fprintf('Initialte the cube now(3*3*3).')
        d = 3;
        R = rubgen(d,0);
       %R = RUBGEN_1(d,0);
       rubplot(R);
       display('Facelet Value Default to be UP.')        
    end
    for i = 1:size(note,1)
        for j = 1:size(note,2)
            switch note(i,j)
                case '*'
                    Outarray(i, 1+(j-1)*sr:sr*j) = zeros(1, sr);
                case '-'
                    assert(j>1)
  %                  Outarray(i, 1+(j-1)*sr:sr*j) = outarray(1+(note2num(note(i,j-1))-1)*sr:sr*note2num(note(i,j-1)));
                otherwise
  %                  Outarray(i, 1+(j-1)*sr:sr*j) = outarray(1+(note2num(note(i,j))-1)*sr:sr*note2num(note(i,j)));
            end
        end
        if PLOT == 1
            subplot(size(Outarray,1),1,i)
            title(['Note in major C line: ', num2str(i)])
            plot(Outarray(i,1:100:ceil(length(Outarray)/100)),'-o')
    %    sound(Outarray(i,:),sr,8)
        end
    end

    OUTPUT = reshape(Outarray', size(Outarray,1), size(Outarray,2));
    %dsp.AudioPlayer(sr,OUTPUT)
    soundsc(OUTPUT, sr, 8);
else
    %dsp.AudioPlayer(sr,ourarray)
    soundsc(outarray, sr, 8);
end

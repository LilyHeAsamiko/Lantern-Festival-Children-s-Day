function Q = quarternions(i)
    majors=[0 2 4 5 7 9 11 12];%startoffset+3 : middle major C
    sr = round(np*sr/ns);
    t = 1:sr;
    t = t/sr;
    %the statement above is equivalent to     
    scale = major;
    startnote = 220*(2^((startnoteoffset+3)/12));
    scale = startnote * scale;
    scale = scale/12;
    dq = 2*pi*cos((2*pi*scale(i))*t);
    Q = 1+dq.^2/2+dq.^3/2.3;
end
function playQuarternions()
    startnoteoffset_1 = 0;
    isminor_1 = 0;
    ns_1 = 4;
    speed_1 = 60;
    sr_1 =  44100;
    s_1 = 8;
    note_1 = ['1','2','3','4','5','6','7','8'];
    unit_1 = sr/ns*speed/60*s/8; 
    PLOT_1 = 1;
    MakeScale_Quarternions(startnoteoffset_1 , isminor_1, PLOT_1, speed_1 , sr_1 , ns_1 , s_1 , note_1, unit_1)
        soundsc(OUTPUT, unit, 8);end
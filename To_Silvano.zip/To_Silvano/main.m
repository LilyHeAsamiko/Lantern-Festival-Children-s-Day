    display('Trial Notes: Twinkle Twinkle Little Star.')
function main()%#codegen
    %fprintf('Trial Notes: Twinkle Twinkle Little Star.')
    note = ['1','1','5','5','6','6','5','-';'4','4','3','3','2','2','1','-'];
    startnoteoffset = 0;
    isminor = 0;
    sr = 44100;
    speed = 60;
    ns =4;
    s = 8;
    unit = sr/ns*speed/60*s/8;
    %note = ['8', '7', '8', '6', '3', '7', '5', '3', '-'; '8', '8', '7', '6', '8', '5', '7', '5'];
    %note =['6', '-', '7', '5', '4', '3', '2', '1', '7', '1', '7', '-', '6', '5', '-'];
    PLOT = 1;
    TTLS = MakeScale_1(startnoteoffset, isminor, PLOT, speed, sr, ns, s, note, unit)
end
function Outarray = MakeScale(startnoteoffset, isminor, sr, ds, s, note, )
%outarray is an array of sound samples on the scale of (-1,1)
%outarray contains the 8 notes of a diatonic musical scale
%each note is played for one second
%the sampling rate is 44100 samples/s 
%startnoteoffset is the number of semitones up or down from middle C at
%which the scale should start.
%If isminor == 0, a major scale is played; otherwise a minor scale is played.
%default: s = 8; ds = 1; for 1 line; ds has to be 2^int
outarray = zeros(1,sr/ds);
majors=[0 2 4 5 7 9 11 12];%startoffset+3 : middle major C
minors=[0 2 3 5 7 8 10 12];
if(isminor == 0)
    scale = majors;
else
    scale = minors;
end
scale = scale/12;
scale = 2.^scale;
%.^ is element-by-element exponentiation
sr = sr/ds;
t = 1:sr;
t = t/sr;
%the statement above is equivalent to 
startnote = 220*(2^((startnoteoffset+3)/12))
scale = startnote * scale;
%Yes, ^ is exponentiation in MATLAB, rather than bitwise XOR as in C++

Outarray = zeros(size(note,1),sr/ds*size(note,2));

for i = 1:s
    outarray(1+(i-1)*sr:sr*i) = sin((2*pi*scale(i))*t);
end 
figure(),
plot(outarray(1:100:ceil(length(outarray)/100)),'-o')
title('Octave in major C')

figure(),
for i = 1:size(note,1)
    for j = 1:size(note,2)
        switch note(i,j)
            case 'o'
                Outarray(i, 1+(j-1)*sr:sr*j) = zeros(1, sr);
            case '-'   
                Outarray(i, 1+(j-1)*sr:sr*j) = outarray(1+(str2num(note(i,j-1))-1)*sr:sr*str2num(note(i,j-1)));
            otherwise
                Outarray(i, 1+(j-1)*sr:sr*j) = outarray(1+(str2num(note(i,j))-1)*sr:sr*str2num(note(i,j)));
        end
    end
    subplot(size(Outarray,1),1,i)
    title(['Note in major C line ', num2str(i)])
    plot(Outarray(i,1:100:ceil(length(Outarray)/100)),'-o')
%    sound(Outarray(i,:),sr,8)
end

OUTPUT = reshape(Outarray', 1, size(Outarray,1)*size(Outarray,2));
soundsc(OUTPUT,sr,8)
end

